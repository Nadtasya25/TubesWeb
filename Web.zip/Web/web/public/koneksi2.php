<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'web';

$conn = mysqli_connect($servername, $username, $password, $database);
if (!$conn){
        die("Connection Failed:".mysqli_connect_error());
    }

$sql = 'SELECT *
FROM users';

$query = mysqli_query($conn, $sql);

if (!$query) {
die ('SQL Error: ' . mysqli_error($conn));
}
?>