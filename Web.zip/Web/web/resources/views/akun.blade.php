<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Akun Saya</title>
	<!-- <link rel="stylesheet" href="styleakun.css" />  -->
	
	<link rel="stylesheet" href="styleakun.css">
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
</head>
@include('partials.navbar')
<body>

<?php
        include "koneksi2.php";
        $query = mysqli_query($conn, 'SELECT * FROM users');
        while ($data = mysqli_fetch_array($query)) {
?>
<section class="sidebar" >
	<div class="kiri">
		<p><img height="50px" src="akun.jpeg" style="padding-right:20px;float:left;"></p>
		<p><?php echo $data['name'] ?></p>

		<br><br><br>
		<ul class="isiakun">
			<li><a href="/akun">Akun Saya</a></li>
			<br><br>
			<li><a href="/vaksin">Data Vaksin</a></li>
			<br><br>
		
		</ul>

	</div>
	<div class="kanan2">
		<ul class="daftar">
			
			<br><br>
			<li>Warga Indonesia</li>
			<br><br>
			<li>Nama Lengkap : </li>
			<br><br>
			<li><?php echo $data['name'] ?></li>
			<br><br>
			<li>Nomor Ponsel : </li>
			<br><br>
			<li><?php echo $data['phone_number'] ?></li>
			<br><br>
			<li>Email : </li>
			<br><br>
			<li><?php echo $data['email'] ?></li>
			<br><br>
		</ul>
		
	</div>
	<div class="kanan">
		<h1>Profil Petugas</h1>
		<p><img src="qr.jpeg" height="200px"></p>
	</div>
</section>
<?php } ?>
<footer>
	<div class="_3pBq_8EN-1PJsZc4LDZCZg">
		<img alt="Peduli Lindungi" class="_2-CaXqeqzVaV5FdRtUi39H" src="pd.svg" width="200px">
		<img alt="Komite Penanganan COVID-19 dan Pemulihan Ekonomi Nasional" class="_2-CaXqeqzVaV5FdRtUi39H" src="kpc.png">
		<img alt="Kementerian Komunikasi dan Informatika" class="_2-CaXqeqzVaV5FdRtUi39H" src="kominfo.png">
		<img alt="Kementerian Kesehatan Republik Indonesia" class="_2-CaXqeqzVaV5FdRtUi39H" src="kemenkes.png">
		<img alt="Kementerian Badan Usaha Milik Negara" class="_2-CaXqeqzVaV5FdRtUi39H" src="bumn.png">
		<img alt="Kementerian Dalam Negeri Republik Indonesia" class="_2-CaXqeqzVaV5FdRtUi39H" src="1.png">
		<img alt="Tentara Nasional Indonesia" class="_2-CaXqeqzVaV5FdRtUi39H" src="2.png">
		<img alt="Kepolisian Negara Republik Indonesia" class="_2-CaXqeqzVaV5FdRtUi39H" src="3.png">
		<img alt="Kementerian Luar Negeri" class="_2-CaXqeqzVaV5FdRtUi39H" src="4.svg" width="70px">
	</div>

    <div class="content">
	    <div class="link-boxes">
	        <ul class="box">
	          <li class="link_name">Pelajari</li>
	          <li><a href="#">Syarat Ketentuan</a></li>
	          <li><a href="#">Kebijakan Privasi Data</a></li> 
	        </ul>
	       <ul class="box">
	          <li class="link_name">Pelayanan</li>
	          <li><a href="#">Periksa Sertifikat</a></li>
	          <li><a href="#">Status Vaksin & Tes COVID</a></li>
	          <li><a href="#">Daftar Lab PCR</a></li>
	          <li><a href="#">Daftar Lab Antigen</a></li>
	          <li><a href="#">Daftar Vaksinasi</a></li>
	        </ul>
	        <ul class="box">
	          <li class="link_name">Hubungi Kami</li>
	          <li><a href="#">Peduli Lindungi@kemenkes.go.id</a></li>
	          <br>
	          <p>KEMENTRIAN KESEHATAN RI<br>Jalan HR Rasuna Said Kav 4 -9,<br>Jakarta Selatan 12950</p>
	        </ul>
	    </div>
    </div>
  </footer>
  <footer class="footer-bawah">
  <div class="footer-bottom">
      <p>copyright &copy; <a href="#">Informatika Developer</a></p>
  </div>
      <div class="social">
        <a href="https://www.youtube.com/channel/UCL8n65BD3_Pp0As4Fo6wdJg"><i class='bx bxl-youtube'></i></a>
        <a href="https://www.instagram.com/pedulilindungi.id/"><i class='bx bxl-instagram-alt' ></i></a>
        <a href="https://twitter.com/PLindungi"><i class='bx bxl-twitter' ></i></a>
    </div>	
  </footer>

</div>
</body>
</html>
@include('partials.footer')