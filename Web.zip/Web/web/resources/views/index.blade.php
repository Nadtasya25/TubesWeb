@extends('layouts.main')

@section('content')
<div class='container my-5'>
@if (Auth::user())
    <section>
    <h1 >Selamat Datang, {{ Auth::user()->name }}</h1>
    <a href="/beranda"><button class="button1">Beranda<i class='bx bxs-chevron-right'></i></button></a>
    <section>
@else
    <h1 class="text-center">Login Dulu</h1>
@endif
</div>
@endsection
