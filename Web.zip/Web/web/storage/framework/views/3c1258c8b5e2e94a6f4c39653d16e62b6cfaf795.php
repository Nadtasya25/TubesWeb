

<?php $__env->startSection('content'); ?>
<div class='container my-5'>
<?php if(Auth::user()): ?>
    <section>
    <h1 >Selamat Datang, <?php echo e(Auth::user()->name); ?></h1>
    <a href="/beranda"><button class="button1">Beranda<i class='bx bxs-chevron-right'></i></button></a>
    <section>
<?php else: ?>
    <h1 class="text-center">Login Dulu</h1>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nanad\Downloads\Web\web\resources\views/index.blade.php ENDPATH**/ ?>