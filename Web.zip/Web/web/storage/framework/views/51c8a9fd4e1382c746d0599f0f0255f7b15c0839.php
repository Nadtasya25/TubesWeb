

<?php $__env->startSection('content'); ?>
<div class='container my-5'>
<?php if(Auth::user()): ?>
    <h1 class="text-center">Selamat Datang, <?php echo e(Auth::user()->name); ?></h1>
<?php else: ?>
    <h1 class="text-center">Login Dulu</h1>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\Web\web\resources\views/index.blade.php ENDPATH**/ ?>