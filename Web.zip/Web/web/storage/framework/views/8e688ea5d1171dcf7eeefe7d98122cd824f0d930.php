 <!-- <h1 class="text-center">Selamat Datang, <?php echo e(Auth::user()->name); ?></h1> -->
 <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="style.css" /> 
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<title>PeduliLindungi</title>
</head>
<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <section id="beranda1"&gt>
	<h2>Lindungi diri dan sekitar dengan<br>berpartisipasi dalam program<br>Vaksinasi COVID-19</h2>
	<a href="/akun"><button class="button1">Masuk Akun <i class='bx bxs-chevron-right'></i></button></a>
</section>
<section id="beranda2"&gt>
	<h1>Temukan Fasilitas Kesehatan yang Melayani Vaksinasi COVID-19</h1>
	<input class="search" type="search" placeholder="Cari Fakes">               
    <input class="button4" type="submit" value="cari">   
</section>
<section id="beranda3"&gt>
	<h3>Tentang</h3>
	<h2>Apa itu PeduliLindungi?</h2>
    <p>PeduliLindungi adalah aplikasi yang dikembangkan untuk membantu instansi pemerintah terkait dalam melakukan pelacakan untuk menghentikan penyebaran Coronavirus Disease (COVID-19).</p>
    <p>Aplikasi ini mengandalkan partisipasi masyarakat untuk saling membagikan data lokasinya saat bepergian agar penelusuran riwayat kontak dengan penderita COVID-19 dapat dilakukan.</p>
    <p>Pengguna aplikasi ini juga akan mendapatkan notifikasi jika berada di keramaian atau berada di zona merah, yaitu area atau kelurahan yang sudah terdata bahwa ada orang yang terinfeksi COVID-19 positif atau ada Pasien Dalam Pengawasan.</p>
</section>
<section id="beranda4"&gt>
	<h3>Tentang</h3>
	<h2>Vaksinasi COVID-19</h2>
    <p>Pada tahap awal, vaksinasi Covid-19 sudah berhasil diberikan kepada seluruh tenaga kesahatan, asisten tenaga kesehatan, dan mahasiswa yang menjalankan pendidikan profesi kedokteran yang bekerja pada fasilitas pelayanan kesehatan. Vaksin tahap kedua juga sudah diberikan kepada lansia, pekerja sektor esensial, dan guru.</p>
    <p>Pemerataan vaksinasi hingga saat ini dilanjutkan untuk masyarakat umum dan terus berjalan hingga berhasil menjangkau seluruh warga negara Indonesia dan warga negara asing yang bertempat tinggal di Indonesia.</p>
    <p>Harapannya dengan upaya pemerataan vaksinasi ini, Indonesia dapat segera bangkit dan terbebas dari penyebaran virus Covid-19.</p>
</section>

<section id = "beranda5"&gt>
	
		<h3>Cara Kerja</h3>
		<iframe allowfullscreen="1" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" title="YouTube video player" src="https://www.youtube.com/embed/2hmI15CajEM?autoplay=0&amp;mute=0&amp;controls=0&amp;origin=https%3A%2F%2Fwww.pedulilindungi.id&amp;playsinline=1&amp;showinfo=0&amp;rel=0&amp;iv_load_policy=3&amp;modestbranding=1&amp;enablejsapi=1&amp;widgetid=1" id="widget2" data-gtm-yt-inspected-1_19="true" width="30%" height="300%" frameborder="0"></iframe>
	
		<h2>Bagaimana PeduliLindungi Bekerja?</h2>
		<p>Pada saat Anda mengunduh PeduliLindungi, sistem akan meminta persetujuan Anda untuk mengaktifkan data lokasi. Dengan kondisi lokasi aktif, maka secara berkala aplikasi akan melakukan identifikasi lokasi Anda serta memberikan informasi terkait keramaian dan zonasi penyebaran COVID-19.</p>
		<p>Hasil tracing ini akan memudahkan pemerintah untuk mengidentifikasi siapa saja yang perlu mendapat penanganan lebih lanjut agar penghentian penyebaran COVID-19 dapat dilakukan. Sehingga, semakin banyak partisipasi masyarakat yang menggunakan aplikasi ini, akan semakin membantu pemerintah dalam melakukan tracing dan tracking. </p>
		<p>PeduliLindungi sangat memperhatikan kerahasiaan pribadi Anda. Data Anda disimpan aman dalam format terenkripsi dan tidak akan dibagikan kepada orang lain. Data Anda hanya akan diakses bila Anda dalam risiko tertular COVID-19 dan perlu segera dihubungi oleh petugas kesehatan. </p>	
		
</section>

<section class="highlight">
	<h2>Kami Peduli dengan Anda</h2>
		<div class="container">
			<div class="box">
				<div class="col-4">
					<img src="g1.jpg" width="80%">
					<h3>Membantu Pelacakan untuk Menghentikan Penyebaran COVID-19</h3>
					<p>Dengan mengaktifkan lokasi, Anda akan membantu instansi pemerintah terkait dalam melakukan pelacakan untuk menghentikan penyebaran Coronavirus Disease (COVID-19).</p>
				</div>
				<div class="col-4">
					<img src="g2.jpg" width="80%">
					<h3>Informasi Zonasi dan Notifikasi Keramaian</h3>					
					<p>Anda akan mendapatkan infomasi area zonasi persebaran COVID-19 (merah, kuning, hijau) sesuai dengan lokasi yang Anda pilih dan mendapatkan notifikasi jika Anda berada di keramaian.</p>
				</div>
				<div class="col-4">
					<img src="g3.jpg" width="80%">
					<h3>Pemeriksaan Kesehatan</h3>
					<p>Jika Anda memerlukan bantuan tenaga kesehatan, Anda bisa menggunakan fitur Teledokter untuk melakukan pemeriksaan kesehatan mandiri dan berkonsultasi dengan tenaga kesehatan terkait kondisi kesehatan Anda.</p>
				</div>
			</div>
		</div>
	</section>


<section class="footer">
	<h2>Mari berpartisipasi melindungi sesama.<br>Unduh PeduliLindungi sekarang!</h2>
	<div class="unduh">
		<a href="https://play.google.com/store"><img src="playstore.png" height="40px" width="110px"></a>
		<a href="https://www.apple.com/app-store/"><img src="apple.png" height="40px" width="110px"></a>
	</div>
</section>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\nanad\Downloads\Web\web\resources\views/beranda.blade.php ENDPATH**/ ?>