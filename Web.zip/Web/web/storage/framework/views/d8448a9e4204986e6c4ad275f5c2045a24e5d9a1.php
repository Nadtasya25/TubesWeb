<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css" /> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <title>Movie Rating</title>
  </head>
  <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <style>
    section{
      padding-top: 20px;
      padding-left: 30px;
    }
    .title{
      padding-left: 90px;
      font-size: 50px;
      margin-bottom: 30px;
      color: #1F4690;
    }
    #name{
      padding:13px 100px; 
      border:2px #e45d5d ;          
      background-color: #ABC9FF; 
      color: #F6F6F6;
      margin-bottom: 5px;
      font-weight:bold;

    }
    #tanggal{
      padding:13px 100px; 
      border:2px #e45d5d ;          
      background-color: #ABC9FF; 
      color: #F6F6F6;
      margin-bottom: 5px;
      font-weight:bold;
    }
    #jenis{
      padding:13px 100px; 
      border:2px #e45d5d ;          
      background-color: #ABC9FF; 
      color: #F6F6F6;
      margin-bottom: 5px;
      margin-top: 0;
      font-weight:bold;
    }
    button{
      background-color: #0078AA;
      color: white;
      border: none;
      color: white;
      padding: 10px 32px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin: 4px 2px;
      margin-bottom: 30px;
    }
    form{
      margin-bottom: 30px;
    }
    table{
      border-collapse: collapse;
      color: #A8A4CE;
    }
    th{
      background-color: #1F4690;
    }
    table, th, td {
        border: 1px solid #1F4690;
    }
    .tabel2 tr:hover {
      background-color: #1F4690;
    }
  </style>
  <body>
  <header>
  </header>
  <section>
    <h1 class="title">Daftar Vaksin</h1>
    <div class="container">
            <div class="tab tab-2">
              <form>
                <input type="text" name="name" id="name" placeholder="Nama Lengkap">
                <br>
                <input type="text" name="tanggal" id="tanggal" placeholder="Tanggal:2 Juni 2022">
                <br>
                <select name="jenis" id="jenis" placeholder="Jenis">
                  <option>Sinovac
                  <option>AstraZeneca
                  <option>Sinopharm
                  <option>Moderna          
                  <option>Pvizer
                  <option>Novavax
                  <option>Sputnik-V
                  <option>Janssen
                  <option>Convidencia
                  <option>Zifivax
                  <option>Booster
                </select>
              </form>
                <button class="button" onclick="addHtmlTableRow();">Add</button>
                <button class="button" onclick="editHtmlTbleSelectedRow();">Edit</button>
                <button class="button" onclick="removeSelectedRow();">Remove</button>
            </div>
            <div class="tab tab-1">
                <table id="table" border="1" width="800px">
                    <tr>
                        <th>Nama Lengkap</th>
                        <th>Tanggal Vaksin</th>
                        <th>Jenis Vaksin</th>
                    </tr>
                    <tr>
                        <td>Nadia</td>
                        <td>2 Juni 2022</td>
                        <td>Sinovac</td>
                    </tr>
                    <tr>
                        <td>Atun</td>
                        <td>3 Juni 2022</td>
                        <td>Sinovac</td>
                    </tr>
                    <tr>
                        <td>Firda</td>
                        <td>4 Juni 2022</td>
                        <td>Sinovac</td>
                    </tr>
                </table>
            </div>
        </div>
        
        <script>
            
            var rIndex,
                table = document.getElementById("table");
            
            // check the empty input
            function checkEmptyInput()
            {
                var isEmpty = false,
                    name = document.getElementById("name").value,
                    tanggal = document.getElementById("tanggal").value,
                    jenis = document.getElementById("jenis").value;
            
                if(name === ""){
                    alert("First Name Connot Be Empty");
                    isEmpty = true;
                }
                else if(tanggal === ""){
                    alert("tanggal Connot Be Empty");
                    isEmpty = true;
                }
                else if(jenis === ""){
                    alert("Jenis Connot Be Empty");
                    isEmpty = true;
                }
                return isEmpty;
            }
            
            // add Row
            function addHtmlTableRow()
            {
                // get the table by id
                // create a new row and cells
                // get value from input text
                // set the values into row cell's
                if(!checkEmptyInput()){
                var newRow = table.insertRow(table.length),
                    cell1 = newRow.insertCell(0),
                    cell2 = newRow.insertCell(1),
                    cell3 = newRow.insertCell(2),
                    name = document.getElementById("name").value,
                    tanggal = document.getElementById("tanggal").value,
                    jenis = document.getElementById("jenis").value;
            
                cell1.innerHTML = name;
                cell2.innerHTML = tanggal;
                cell3.innerHTML = jenis;
                // call the function to set the event to the new row
                selectedRowToInput();
            }
            }
            
            // display selected row data into input text
            function selectedRowToInput()
            {
                
                for(var i = 1; i < table.rows.length; i++)
                {
                    table.rows[i].onclick = function()
                    {
                      // get the seected row index
                      rIndex = this.rowIndex;
                      document.getElementById("name").value = this.cells[0].innerHTML;
                      document.getElementById("tanggal").value = this.cells[1].innerHTML;
                      document.getElementById("jenis").value = this.cells[2].innerHTML;
                    };
                }
            }
            selectedRowToInput();
            
            function editHtmlTbleSelectedRow()
            {
                var name = document.getElementById("name").value,
                    tanggal = document.getElementById("tanggal").value,
                    jenis = document.getElementById("jenis").value;
               if(!checkEmptyInput()){
                table.rows[rIndex].cells[0].innerHTML = name;
                table.rows[rIndex].cells[1].innerHTML = tanggal;
                table.rows[rIndex].cells[2].innerHTML = jenis;
              }
            }
            
            function removeSelectedRow()
            {
                table.deleteRow(rIndex);
                // clear input text
                document.getElementById("name").value = "";
                document.getElementById("tanggal").value = "";
                document.getElementById("jenis").value = "";
            }
        </script>
  </section>
  <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH C:\Users\nanad\Downloads\Web\web\resources\views/vaksin.blade.php ENDPATH**/ ?>