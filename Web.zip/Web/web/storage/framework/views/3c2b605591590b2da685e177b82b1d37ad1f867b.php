<footer>
	<div class="_3pBq_8EN-1PJsZc4LDZCZg">
		<img alt="Peduli Lindungi" class="_2-CaXqeqzVaV5FdRtUi39H" src="pd.svg" width="200px">
		<img alt="Komite Penanganan COVID-19 dan Pemulihan Ekonomi Nasional" class="_2-CaXqeqzVaV5FdRtUi39H" src="kpc.png">
		<img alt="Kementerian Komunikasi dan Informatika" class="_2-CaXqeqzVaV5FdRtUi39H" src="kominfo.png">
		<img alt="Kementerian Kesehatan Republik Indonesia" class="_2-CaXqeqzVaV5FdRtUi39H" src="kemenkes.png">
		<img alt="Kementerian Badan Usaha Milik Negara" class="_2-CaXqeqzVaV5FdRtUi39H" src="bumn.png">
		<img alt="Kementerian Dalam Negeri Republik Indonesia" class="_2-CaXqeqzVaV5FdRtUi39H" src="1.png">
		<img alt="Tentara Nasional Indonesia" class="_2-CaXqeqzVaV5FdRtUi39H" src="2.png">
		<img alt="Kepolisian Negara Republik Indonesia" class="_2-CaXqeqzVaV5FdRtUi39H" src="3.png">
		<img alt="Kementerian Luar Negeri" class="_2-CaXqeqzVaV5FdRtUi39H" src="4.svg" width="70px">
	</div>

    <div class="content">
	    <div class="link-boxes">
	        <ul class="box">
	          <li class="link_name">Pelajari</li>
	          <li><a href="#">Syarat Ketentuan</a></li>
	          <li><a href="#">Kebijakan Privasi Data</a></li> 
	        </ul>
	       <ul class="box">
	          <li class="link_name">Pelayanan</li>
	          <li><a href="#">Periksa Sertifikat</a></li>
	          <li><a href="#">Status Vaksin & Tes COVID</a></li>
	          <li><a href="#">Daftar Lab PCR</a></li>
	          <li><a href="#">Daftar Lab Antigen</a></li>
	          <li><a href="#">Daftar Vaksinasi</a></li>
	        </ul>
	        <ul class="box">
	          <li class="link_name">Hubungi Kami</li>
	          <li><a href="#">Peduli Lindungi@kemenkes.go.id</a></li>
	          <br>
	          <p>KEMENTRIAN KESEHATAN RI<br>Jalan HR Rasuna Said Kav 4 -9,<br>Jakarta Selatan 12950</p>
	        </ul>
	    </div>
    </div>
  </footer>
  <footer class="footer-bawah">
  <div class="footer-bottom">
      <p>copyright &copy; <a href="#">Informatika Developer</a></p>
  </div>
      <div class="social">
        <a href="https://www.youtube.com/channel/UCL8n65BD3_Pp0As4Fo6wdJg"><i class='bx bxl-youtube'></i></a>
        <a href="https://www.instagram.com/pedulilindungi.id/"><i class='bx bxl-instagram-alt' ></i></a>
        <a href="https://twitter.com/PLindungi"><i class='bx bxl-twitter' ></i></a>
    </div>	
  </footer><?php /**PATH C:\Users\nanad\Downloads\Web\web\resources\views/partials/footer.blade.php ENDPATH**/ ?>