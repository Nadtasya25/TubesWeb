

<?php $__env->startSection('content'); ?>
    <br/>
    <form method="POST" action="<?php echo e(url('pembeli')); ?>">
        <?php echo csrf_field(); ?> 
        Nama        : <input type="text" name ="nama"><br/>
        Alamat      : <input type="text" name ="alamat"><br/>
        Nama Obat   : <input type="text" name ="nama_obat"><br/>
        Jumlah      : <input type="text" name ="jumlah"><br/>
        Tanggal Beli: <input type="text" name ="tanggal_beli"><br/>
        
        <button type ='submit'>Simpan</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\Web\web\resources\views/pembeli/create.blade.php ENDPATH**/ ?>