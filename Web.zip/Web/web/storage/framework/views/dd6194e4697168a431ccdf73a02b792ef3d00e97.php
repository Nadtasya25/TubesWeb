

<?php $__env->startSection('content'); ?>
<br/>
<table class="table-bordered table" >
    
    <a class="btn btn-info" href="<?php echo e(url('pembeli/create')); ?>">Tambah</a>
    
    <br/><br/>
    <tr class="text-center">
        <th>Nama</th>
        <th>Alamat</th>
        <th>Nama Obat</th>
        <th>Jumlah</th>
        <th>Tanggal Beli</th>
        <th colspan="2">AKSI</th>
    </tr>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($value->nama); ?></td>
            <td><?php echo e($value->alamat); ?></td>
            <td><?php echo e($value->nama_obat); ?></td>
            <td><?php echo e($value->jumlah); ?></td>
            <td><?php echo e($value->tanggal_beli); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\Web\web\resources\views/pembeli/index.blade.php ENDPATH**/ ?>